﻿using ACMWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ACMWeb.BLL
{
    public class Services
    {
        public static int CalcPiResult(int SemestrId, int PiId) {
            using (var db = new ACMDbContext())
            {
                
            }

            return 1;
        }
    }
}